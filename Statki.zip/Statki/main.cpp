#include <iostream>
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>
#include <allegro5/allegro_image.h>
#include <vector>
#include <ctime>
#include <cstdlib>

const int boardSize = 10;                                           // rozmiar planszy
const int cellSize = 50;                                            // rozmiar komorki
const int screenWidth = 1280;                                       // szerokosc okna
const int screenHeight = 720;                                       // wysokosc okna
const ALLEGRO_COLOR COLOR_BACKGROUND = al_map_rgb(0, 105, 148);     // kolor tla
const ALLEGRO_COLOR COLOR_MENU_BUTTON = al_map_rgb(155, 49, 14);    // kolor przyciskow w menu
const ALLEGRO_COLOR COLOR_CELL_SHIP = al_map_rgb(192, 192, 192);    // kolor statkow
const ALLEGRO_COLOR COLOR_CELL_HIT = al_map_rgb(255, 0, 0);         // kolor trafionego statku
const ALLEGRO_COLOR COLOR_CELL_SUNK = al_map_rgb(0, 0, 128);        // kolor zatopionego statku
const ALLEGRO_COLOR COLOR_CELL_MISS = al_map_rgb(255, 255, 255);    // kolor pudla
const ALLEGRO_COLOR COLOR_CELL_EMPTY = al_map_rgb(0, 0, 255);       // kolor pustego pola
const ALLEGRO_COLOR COLOR_CELL_VALID = al_map_rgb(124, 252, 0);     // kolor poprawnego pola

struct Ship {
    int size;           // rozmiar statku
    int x, y;           // wspolrzedne statku
    bool isVertical;    // czy statek jest pionowy
};

struct Player {
    std::vector<std::vector<int>> board;                            // plansza gracza
    std::vector<Ship> ships;                                        // statki gracza
    int hitCount;                                                   // liczba trafien

    Player() {                                                      // konstruktor
        hitCount = 0;                                               // poczatkowa liczba trafien
        board.resize(boardSize, std::vector<int>(boardSize, 0));    // ustawienie rozmiaru planszy (10x10 z wartoscia "0")
    }
};

class Game {
public:
    Game();     // konstruktor
    ~Game();    // destruktor
    void run(); // funkcja uruchamiajaca gre

private:
    void drawBoards();                                                                          // funkcja rysujaca plansze
    void update();                                                                              // glowna petla gry
    void humanPlaceShips();                                                                     // funkcja umieszczajaca statki przez gracza
    void computerPlaceShips();                                                                  // funkcja umieszczajaca statki przez komputer
    bool isValidPlacement(const Ship& ship, const std::vector<std::vector<int>>& board) const;  // funkcja sprawdzajaca czy mozna umiescic statek
    bool isGameOver() const;                                                                    // funkcja sprawdzajaca czy gra sie skonczyla
    bool menu();                                                                                // funkcja menu

    ALLEGRO_DISPLAY* display;           // okno gry
    ALLEGRO_FONT* font; 	            // czcionka
    ALLEGRO_BITMAP* battleship;         // obrazek statku
    ALLEGRO_EVENT_QUEUE* eventQueue;    // kolejka zdarzen
    ALLEGRO_TIMER* timer;			    // timer

    Player human; 					    // gracz
    Player computer;				    // komputer
    bool humanTurn;					    // zmienna przechowujaca status tur
    bool gameOver;					    // zmienna przechowujaca status konca gry
};

Game::Game() {
    al_init(); 																	    // inicjalizacja biblioteki allegro
    al_install_keyboard(); 														    // inicjalizacja klawiatury
    al_install_mouse(); 														    // inicjalizacja myszki
    al_init_primitives_addon(); 												    // inicjalizacja rysowania figur
    al_init_font_addon(); 														    // inicjalizacja czcionek
    al_init_ttf_addon(); 														    // inicjalizacja ttf
    al_init_image_addon(); 														    // inicjalizacja obrazkow

    display = al_create_display(screenWidth, screenHeight); 						// tworzenie okna gry
    font = al_load_ttf_font("arial.ttf", 50, 0); 									// wczytywanie czcionki
    battleship = al_load_bitmap("battleship.png"); 									// wczytywanie obrazka statku
    eventQueue = al_create_event_queue(); 											// tworzenie kolejki zdarzen
    timer = al_create_timer(1.0 / 15); 												// tworzenie timera (15 fps)

    al_register_event_source(eventQueue, al_get_mouse_event_source()); 				// rejestrowanie zdarzen z myszki
    al_register_event_source(eventQueue, al_get_display_event_source(display)); 	// rejestrowanie zdarzen z okna gry
    al_register_event_source(eventQueue, al_get_timer_event_source(timer)); 		// rejestrowanie zdarzen z timera

    humanTurn = true; 															    // poczatkowa wartosc zmiennej humanTurn
    gameOver = false; 															    // poczatkowa wartosc zmiennej gameOver
}

Game::~Game() {
    al_destroy_display(display); 		    // usuwanie okna gry
    al_destroy_font(font); 				    // usuwanie czcionki
    al_destroy_bitmap(battleship); 		    // usuwanie obrazka statku
    al_destroy_event_queue(eventQueue); 	// usuwanie kolejki zdarzen
    al_destroy_timer(timer); 			    // usuwanie timera
}

void Game::drawBoards() {
    ALLEGRO_COLOR color = COLOR_CELL_EMPTY;                                                                                                     // zmienna przechowujaca kolor
    al_clear_to_color(COLOR_BACKGROUND);																										// czyszczenie ekranu

    // rysowanie planszy gracza
    al_draw_text(font, al_map_rgb(255, 255, 255), screenWidth/4, 25, ALLEGRO_ALIGN_CENTER, "Gracz");											// napis "Gracz"

    for (int i = 0; i < boardSize; ++i) {																										// rysowanie planszy gracza (wiersze)
        for (int j = 0; j < boardSize; ++j) {																									// rysowanie planszy gracza (kolumny)
            if (human.board[i][j] == 0) {																										// jesli pole jest puste
                color = COLOR_CELL_EMPTY;
            }
            else if (human.board[i][j] == 1) {																									// jesli pole jest zajete przez statek
                color = COLOR_CELL_SHIP;
            }
            else if (human.board[i][j] == 2) {																									// jesli pole jest puste (nie trafione)
                color = COLOR_CELL_MISS;
            }
            else if (human.board[i][j] == 3) {																									// jesli pole jest zajete przez statek (trafione)
                color = COLOR_CELL_HIT;
            }

            al_draw_filled_rectangle(j* cellSize + 70, i* cellSize + 100, (j + 1)* cellSize + 70, (i + 1)* cellSize + 100, color);				// rysowanie pola
            al_draw_rectangle(j* cellSize + 70, i* cellSize + 100, (j + 1)* cellSize + 70, (i + 1)* cellSize + 100, al_map_rgb(0, 0, 0), 1);	// rysowanie ramki
        }
    }

    // rysowanie planszy komputera
    al_draw_text(font, al_map_rgb(255, 255, 255), 3 * screenWidth / 4, 25, ALLEGRO_ALIGN_CENTER, "Komputer");									// napis "Komputer"

    for (int i = 0; i < boardSize; ++i) {																										// rysowanie planszy komputera (wiersze)
        for (int j = 0; j < boardSize; ++j) {																									// rysowanie planszy komputera (kolumny)
            if (computer.board[i][j] == 0) {																									// jesli pole jest puste
                color = COLOR_CELL_EMPTY;
            }
            else if (computer.board[i][j] == 1) {																								// jesli pole jest zajete przez statek
                color = COLOR_CELL_EMPTY;
            }
            else if (computer.board[i][j] == 2) {																								// jesli pole jest puste (nie trafione)
                color = COLOR_CELL_MISS;
            }
            else if (computer.board[i][j] == 3) {																								// jesli pole jest zajete przez statek (trafione)
                color = COLOR_CELL_HIT;
            }

            al_draw_filled_rectangle(j * cellSize + 710, i * cellSize + 100, (j + 1) * cellSize + 710, (i + 1) * cellSize + 100, color);           // rysowanie pola
            al_draw_rectangle(j * cellSize + 710, i * cellSize + 100, (j + 1) * cellSize + 710, (i + 1) * cellSize + 100, al_map_rgb(0, 0, 0), 1); // rysowanie ramki
        }
    }

    al_flip_display(); 																														    // odswiezanie ekranu
}

void Game::update() {
    while (!gameOver) { 																    // petla gry
        ALLEGRO_EVENT event; 																// zmienna przechowujaca zdarzenie
        al_wait_for_event(eventQueue, &event); 												// oczekiwanie na zdarzenie
        if (event.type == ALLEGRO_EVENT_TIMER) {
            drawBoards(); 																	// odswiezanie plansz
        }
        else if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { 								// zamkniete okno gry
            break;
        }
        else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN && humanTurn) { 		    	// oddanie strzalu przez gracza
            int mouseX = event.mouse.x;
            int mouseY = event.mouse.y;

            int cellX = (mouseX - 710) / cellSize; 											// obliczanie wspolrzednych pola
            int cellY = (mouseY - 100) / cellSize; 											// obliczanie wspolrzednych pola

            if (cellX >= 0 && cellX < boardSize && cellY >= 0 && cellY < boardSize) { 		// sprawdzanie czy kliknieto w plansze
                if (computer.board[cellY][cellX] == 1) { 									// jesli trafiono statek
                    computer.board[cellY][cellX] = 3;
                    human.hitCount++; 
                }
                else if (computer.board[cellY][cellX] == 0) { 								// jesli nie trafiono statku
                    computer.board[cellY][cellX] = 2;
                    humanTurn = false;
                }
            }
        }

        if (!humanTurn && !gameOver) { 														// oddanie strzalu przez komputer
            int cellX = rand() % boardSize;
            int cellY = rand() % boardSize;

            if (human.board[cellY][cellX] == 1) { 											// jesli trafiono statek
                human.board[cellY][cellX] = 3;
                computer.hitCount++;
            }
            else if (human.board[cellY][cellX] == 0) { 										// jesli nie trafiono statku
                human.board[cellY][cellX] = 2;
                humanTurn = true;
            }
        }

        if (isGameOver()) { 																// sprawdzanie czy gra sie skonczyla
            gameOver = true;
            std::cout << (human.hitCount == 12 ? "Gracz wygral!" : "Komputer wygral!") << std::endl; 	// wyswietlanie komunikatu o zwyciezcy w konsoli
            break;
        }
    }
}

void Game::humanPlaceShips() {
    std::vector<int> shipSizes = { 3, 3, 2, 2, 1, 1 }; 									// rozmiary statkow

    for (int z = 0; z < 6; z++) { 													// petla dla kazdego statku
        int shipSize = shipSizes[z]; 													// pobieranie rozmiaru statku
        Ship ship; 																		    // tworzenie statku
        ship.size = shipSize; 															    // ustawianie rozmiaru statku
        ship.isVertical = true; 														    // ustawianie orientacji statku
        bool placed = false; 															    // zmienna przechowujaca informacje czy statek zostal umieszczony
        int mouseX = 0, mouseY = 0; 													    // zmienne przechowujace wspolrzedne myszy

        while (!placed) { 																// petla umieszczania statku
            bool shipSet = false; 														    // zmienna przechowujaca informacje czy statek zostal ustawiony

            while (!shipSet) { 															    // petla ustawiania statku
                ALLEGRO_EVENT event;
                al_wait_for_event(eventQueue, &event); 										// oczekiwanie na zdarzenie
                if (event.type == ALLEGRO_EVENT_TIMER) {
                    drawBoards(); 															// odswiezanie plansz
                    if (ship.isVertical && isValidPlacement(ship, human.board)) { 			// rysowanie propozycji umieszczenia statku
                        al_draw_rectangle(ship.x * cellSize + 70, ship.y * cellSize + 100, (ship.x + 1) * cellSize + 70, (ship.y + 1) * cellSize + 100 + (ship.size - 1) * cellSize, COLOR_CELL_VALID, 3);
                    }
                    else if (!ship.isVertical && isValidPlacement(ship, human.board))
                    {
                        al_draw_rectangle(ship.x * cellSize + 70, ship.y * cellSize + 100, (ship.x + 1) * cellSize + 70 + (ship.size - 1) * cellSize, (ship.y + 1) * cellSize + 100, COLOR_CELL_VALID, 3);
                    }
                    al_flip_display(); 														// odswiezanie ekranu
				}
                else if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { 						// zamkniete okno gry
                    placed = true;
                    break;
                }
                else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN && event.mouse.button == 1) { 	// wybranie pozycji statku (prawy przycisk myszy
                    mouseX = event.mouse.x;
                    mouseY = event.mouse.y;

                    ship.x = (mouseX - 70) / cellSize; 										// obliczanie wspolrzednych statku
                    ship.y = (mouseY - 100) / cellSize; 									// obliczanie wspolrzednych statku

                    shipSet = true; 														// ustawienie statku
                }
                else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN && event.mouse.button == 2) { 	// zmiana orientacji statku (lewy przycisk myszy)
                    if (ship.isVertical) {
                        ship.isVertical = false;
                    }
                    else {
                        ship.isVertical = true;
                    }
                }
                else if (event.type == ALLEGRO_EVENT_MOUSE_AXES) { 							// ruch myszy (zmienne do porpozycji statku)
                    ship.x = (event.mouse.x - 70) / cellSize;
                    ship.y = (event.mouse.y - 100) / cellSize;
                }
            }

            if (isValidPlacement(ship, human.board)) { 										// jesli statek zostal ustawiony poprawnie - wczytanie go do planszy
                for (int i = 0; i < ship.size; ++i) {
                    if (ship.isVertical) { 													// ustawienie statku w zaleznosci od orientacji
                        human.board[ship.y + i][ship.x] = 1;
                    }
                    else {
                        human.board[ship.y][ship.x + i] = 1;
                    }
                }

                human.ships.push_back(ship); 												// dodanie statku do wektora statkow gracza
                placed = true;
            }
        }
    }
}

void Game::computerPlaceShips() {
    std::vector<int> shipSizes = { 3, 3, 2, 2, 1, 1 }; 									// rozmiary statkow
    for (int z = 0; z < 6; z++) { 													// petla dla kazdego statku
        int shipSize = shipSizes[z]; 													// pobieranie rozmiaru statku
        Ship ship; 																		    // tworzenie statku
        ship.size = shipSize; 															    // ustawianie rozmiaru statku
        
        bool placed = false;
        while (!placed) { 																// petla umieszczania statku w sposob losowy
            ship.isVertical = rand() % 2;
            ship.x = rand() % (ship.isVertical ? boardSize : boardSize - ship.size + 1);
            ship.y = rand() % (ship.isVertical ? boardSize - ship.size + 1 : boardSize);

            if (isValidPlacement(ship, computer.board)) { 								// jesli statek zostal ustawiony poprawnie - wczytanie go do planszy
                for (int i = 0; i < ship.size; ++i) {
                    if (ship.isVertical) { 												// ustawienie statku w zaleznosci od orientacji
                        computer.board[ship.y + i][ship.x] = 1;
                    }
                    else {
                        computer.board[ship.y][ship.x + i] = 1;
                    }
                }

                computer.ships.push_back(ship); 										// dodanie statku do wektora statkow komputera
                placed = true;
            }
        }
    }
}

bool Game::isValidPlacement(const Ship& ship, const std::vector<std::vector<int>>& board) const {
    int dx[] = { -1, 0, 1, 0, -1, 1, 1, -1 }; 												        // tablica wspolrzednych x sasiadow (lewo, dol, prawo, gora, lewo-gora, prawo-dol, prawo-gora, lewo-dol)
    int dy[] = { 0, 1, 0, -1, -1, 1, -1, 1 }; 												        // tablica wspolrzednych y sasiadow

    for (int i = 0; i < ship.size; ++i) { 													        // petla dla kazdego pola statku
        int x = ship.x + (ship.isVertical ? 0 : i); 											    // ustalanie wspolrzednej x
        int y = ship.y + (ship.isVertical ? i : 0); 											    // ustalanie wspolrzednej y

        if (x < 0 || x >= board[0].size() || y < 0 || y >= board.size() || board[y][x] != 0) { 	    // sprawdzanie czy pole dla statku jest puste
            return false;
        }

        for (int j = 0; j < 8; ++j) { 														        // petla dla kazdego sasiada
            int nx = x + dx[j];
            int ny = y + dy[j];

            if (nx >= 0 && ny >= 0 && nx < board[0].size() && ny < board.size() && board[ny][nx] != 0) { // sprawdzanie czy pole sasiadujace nie jest zajete
                return false;
            }
        }
    }

    return true;
}

bool Game::isGameOver() const {
    return human.hitCount == 12 || computer.hitCount == 12; 					// sprawdzanie czy gra sie skonczyla (gry ktoras ze stron ma 12 pumktow)
}

bool Game::menu() {
    al_clear_to_color(COLOR_BACKGROUND); 										// czyszczenie ekranu

    al_draw_bitmap(battleship, 500, 300, NULL); // wyswietlenie statku

    // Rysowanie przycisk�w
    al_draw_filled_rounded_rectangle(50, 350, 400, 450, 5, 5, COLOR_MENU_BUTTON); // rysowanie prostokata pod napisem GRAJ
    al_draw_rounded_rectangle(50, 350, 400, 450, 5, 5, COLOR_CELL_SHIP, 10); // rysowanie ramki prostokata pod napisem GRAJ
    al_draw_filled_rounded_rectangle(50, 500, 400, 600, 5, 5, COLOR_MENU_BUTTON); // rysowanie prostokata pod napisem WYJDZ
    al_draw_rounded_rectangle(50, 500, 400, 600, 5, 5, COLOR_CELL_SHIP, 10); // rysowanie ramki prostokata pod napisem WYJDZ

    // Rysowanie tekstu
    font = al_load_ttf_font("arial.ttf", 164, NULL); // ustawienie czcionki
    al_draw_text(font, COLOR_CELL_SHIP, screenWidth / 2, 50, ALLEGRO_ALIGN_CENTER, "STATKI"); // wypisanie STATKI
    font = al_load_font("arial.ttf", 72, NULL); // ustawienie czcionki
    al_draw_text(font, COLOR_CELL_MISS, 125, 370, ALLEGRO_ALIGN_LEFT, "GRAJ"); // wypisanie GRAJ
    al_draw_text(font, COLOR_CELL_MISS, 85, 520, ALLEGRO_ALIGN_LEFT, "WYJDZ"); // wypisanie WYJDZ
    font = al_load_ttf_font("arial.ttf", 50, NULL); // ustawienie czcionki

    bool running = true;
    while (running) // petla menu
    {
        ALLEGRO_EVENT event;                        // zmienna przechowujaca zdarzenie
        al_wait_for_event(eventQueue, &event);      // oczekiwanie na zdarzenie
        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE) { // jesli zostalo zamkniete okno
            return false;
        }
        else if (event.type == ALLEGRO_EVENT_MOUSE_BUTTON_UP) // jesli zostal wcisniety przycisk myszy
        {
            if (event.mouse.button == 1) { // lewy przycisk myszy
                int x = event.mouse.x; // pobranie wspolrzednej x
                int y = event.mouse.y; // pobranie wspolrzednej y
                if (x >= 50 && x <= 400 && y >= 350 && y <= 450) { // jesli zostal wcisniety przycisk GRAJ
                    running = false;
                    return true;
                }
                else if (x >= 50 && x <= 400 && y >= 500 && y <= 600) { // jesli zostal wcisniety przycisk WYJDZ
                    running = false;
                    return false;
                }
            }
        }
        al_flip_display(); // odswiezenie ekranu
    }
    return false;
}

void Game::run() {
    al_start_timer(timer); // rozpoczecie timera
    if (menu()) // jesli zostal wybrany przycisk GRAJ program przechodzi do gry
    {
        humanPlaceShips(); // umieszczenie statkow przez gracza
        computerPlaceShips(); // umieszczenie statkow przez komputer
        update(); // glowna petla gry
    }
}

int main(void) {
    srand(time(NULL)); // ustawienie ziarna losowania
    Game game; // utworzenie obiektu gry
    game.run(); // uruchomienie gry

    return 0;
}